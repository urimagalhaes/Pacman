package pacman;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.Timer;

public class GamePanel extends JPanel implements ActionListener {
    private static final int HUD_ALTURA = 40;
    private static final int RODAPE_ALTURA = 35;

    private final Labirinto labirinto;
    private final Jogador jogador;
    private final List<Fantasma> fantasmas;
    private final Timer timer;

    private int pontuacao = 0;
    private int tempoAssustado = 0;
    private String estadoJogo = "INICIO"; // INICIO, JOGANDO, VITORIA, DERROTA

    public GamePanel() {
        labirinto = new Labirinto();
        int largura = labirinto.getLarguraPixels();
        int altura = labirinto.getAlturaPixels() + HUD_ALTURA + RODAPE_ALTURA;

        setPreferredSize(new Dimension(largura, altura));
        setBackground(Color.BLACK);
        setFocusable(true);

        int tam = Labirinto.TILE - 2;
        jogador = new Jogador(9 * Labirinto.TILE + 1, 16 * Labirinto.TILE + 1, tam);

        fantasmas = new ArrayList<>();
        fantasmas.add(new Fantasma(9 * Labirinto.TILE + 1, 10 * Labirinto.TILE + 1, tam, Color.RED));
        fantasmas.add(new Fantasma(8 * Labirinto.TILE + 1, 10 * Labirinto.TILE + 1, tam, Color.PINK));
        fantasmas.add(new Fantasma(10 * Labirinto.TILE + 1, 10 * Labirinto.TILE + 1, tam, Color.ORANGE));

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                processarTecla(e.getKeyCode());
            }
        });

        timer = new Timer(16, this); // ~60 FPS
        timer.start();
    }

    private void processarTecla(int keyCode) {
        if (estadoJogo.equals("INICIO") && keyCode == KeyEvent.VK_ENTER) {
            estadoJogo = "JOGANDO";
            return;
        }

        if ((estadoJogo.equals("VITORIA") || estadoJogo.equals("DERROTA")) && keyCode == KeyEvent.VK_R) {
            reiniciarJogoCompleto();
            return;
        }

        if (estadoJogo.equals("JOGANDO")) {
            switch (keyCode) {
                case KeyEvent.VK_UP, KeyEvent.VK_W -> jogador.setProximaDirecao(0, -1);
                case KeyEvent.VK_DOWN, KeyEvent.VK_S -> jogador.setProximaDirecao(0, 1);
                case KeyEvent.VK_LEFT, KeyEvent.VK_A -> jogador.setProximaDirecao(-1, 0);
                case KeyEvent.VK_RIGHT, KeyEvent.VK_D -> jogador.setProximaDirecao(1, 0);
            }
        }
    }

    private void reiniciarJogoCompleto() {
        pontuacao = 0;
        tempoAssustado = 0;
        labirinto.reiniciar();
        jogador.resetarVidas();
        resetarPosicoes();
        estadoJogo = "JOGANDO";
    }

    private void resetarPosicoes() {
        jogador.setPosicao(9 * Labirinto.TILE + 1, 16 * Labirinto.TILE + 1);
        for (Fantasma f : fantasmas) {
            f.voltarParaBase();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (estadoJogo.equals("JOGANDO")) {
            atualizarLogica();
        }
        repaint();
    }

    private void atualizarLogica() {
        jogador.atualizar(labirinto);

        // Coleta de pastilhas
        int centroX = jogador.getX() + Labirinto.TILE / 2;
        int centroY = jogador.getY() + Labirinto.TILE / 2;
        int pontosGanhos = labirinto.coletarItem(centroX, centroY);

        if (pontosGanhos > 0) {
            pontuacao += pontosGanhos;
            if (pontosGanhos == 50) {
                tempoAssustado = 400; // ~6,5 segundos de vulnerabilidade
                for (Fantasma f : fantasmas) f.setAssustado(true);
            }
        }

        if (labirinto.getPastilhasRestantes() == 0) {
            estadoJogo = "VITORIA";
            return;
        }

        // Controle do tempo de vulnerabilidade dos fantasmas
        if (tempoAssustado > 0) {
            tempoAssustado--;
            if (tempoAssustado == 0) {
                for (Fantasma f : fantasmas) f.setAssustado(false);
            }
        }

        // Atualização e colisão com fantasmas
        for (Fantasma f : fantasmas) {
            f.atualizar(labirinto);
            if (jogador.getBounds().intersects(f.getBounds())) {
                if (f.isAssustado()) {
                    pontuacao += 200;
                    f.voltarParaBase();
                } else {
                    jogador.perderVida();
                    if (jogador.getVidas() <= 0) {
                        estadoJogo = "DERROTA";
                    } else {
                        resetarPosicoes();
                    }
                    break;
                }
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // HUD Superior
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Monospaced", Font.BOLD, 18));
        g2d.drawString("Pontos: " + pontuacao, 12, 26);

        // Desenho do Labirinto e Entidades (deslocados pelo HUD)
        labirinto.desenhar(g2d, HUD_ALTURA);

        g2d.translate(0, HUD_ALTURA);
        jogador.desenhar(g2d);
        for (Fantasma f : fantasmas) {
            f.desenhar(g2d);
        }
        g2d.translate(0, -HUD_ALTURA);

        // HUD Inferior (Vidas)
        int yRodape = HUD_ALTURA + labirinto.getAlturaPixels() + 8;
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Monospaced", Font.PLAIN, 14));
        g2d.drawString("Vidas:", 12, yRodape + 14);
        g2d.setColor(Color.YELLOW);
        for (int i = 0; i < jogador.getVidas(); i++) {
            g2d.fillArc(72 + i * 24, yRodape, 16, 16, 30, 300);
        }

        // Telas de Estado
        if (!estadoJogo.equals("JOGANDO")) {
            desenharSobreposicao(g2d);
        }
    }

    private void desenharSobreposicao(Graphics2D g2d) {
        g2d.setColor(new Color(0, 0, 0, 185));
        g2d.fillRect(0, HUD_ALTURA, getWidth(), labirinto.getAlturaPixels());

        g2d.setFont(new Font("Monospaced", Font.BOLD, 24));
        String titulo = "";
        String subtitulo = "";

        switch (estadoJogo) {
            case "INICIO" -> {
                g2d.setColor(Color.YELLOW);
                titulo = "PAC-MAN JAVA SWING";
                subtitulo = "Pressione ENTER para iniciar";
            }
            case "VITORIA" -> {
                g2d.setColor(Color.GREEN);
                titulo = "VOCÊ VENCEU!";
                subtitulo = "Pontos: " + pontuacao + " | R para reiniciar";
            }
            case "DERROTA" -> {
                g2d.setColor(Color.RED);
                titulo = "GAME OVER";
                subtitulo = "Pontos: " + pontuacao + " | R para reiniciar";
            }
        }

        int larguraTitulo = g2d.getFontMetrics().stringWidth(titulo);
        g2d.drawString(titulo, (getWidth() - larguraTitulo) / 2, getHeight() / 2 - 15);

        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Monospaced", Font.PLAIN, 15));
        int larguraSub = g2d.getFontMetrics().stringWidth(subtitulo);
        g2d.drawString(subtitulo, (getWidth() - larguraSub) / 2, getHeight() / 2 + 20);
    }
}