package pacman;

import java.awt.Color;
import java.awt.Graphics2D;

public class Labirinto {
    public static final int TILE = 24;

    // 1 = Parede, 0 = Pastilha comum, 2 = Pastilha de poder, 3 = Vazio, 4 = Porta dos fantasmas
    private final int[][] mapaOriginal = {
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        {1,2,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,2,1},
        {1,0,1,1,0,1,1,1,0,1,0,1,1,1,0,1,1,0,1},
        {1,0,1,1,0,1,1,1,0,1,0,1,1,1,0,1,1,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,1,0,1,0,1,1,1,1,1,0,1,0,1,1,0,1},
        {1,0,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0,1},
        {1,1,1,1,0,1,1,1,3,1,3,1,1,1,0,1,1,1,1},
        {3,3,3,1,0,1,3,3,3,3,3,3,3,1,0,1,3,3,3},
        {1,1,1,1,0,1,3,1,1,4,1,1,3,1,0,1,1,1,1},
        {0,0,0,0,0,3,3,1,3,3,3,1,3,3,0,0,0,0,0},
        {1,1,1,1,0,1,3,1,1,1,1,1,3,1,0,1,1,1,1},
        {3,3,3,1,0,1,3,3,3,3,3,3,3,1,0,1,3,3,3},
        {1,1,1,1,0,1,0,1,1,1,1,1,0,1,0,1,1,1,1},
        {1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1},
        {1,0,1,1,0,1,1,1,0,1,0,1,1,1,0,1,1,0,1},
        {1,2,0,1,0,0,0,0,0,3,0,0,0,0,0,1,0,2,1},
        {1,1,0,1,0,1,0,1,1,1,1,1,0,1,0,1,0,1,1},
        {1,0,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0,1},
        {1,0,1,1,1,1,1,1,0,1,0,1,1,1,1,1,1,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
    };

    private int[][] mapa;
    private int pastilhasRestantes;

    public Labirinto() {
        reiniciar();
    }

    public void reiniciar() {
        mapa = new int[mapaOriginal.length][mapaOriginal[0].length];
        pastilhasRestantes = 0;
        for (int r = 0; r < mapaOriginal.length; r++) {
            for (int c = 0; c < mapaOriginal[0].length; c++) {
                mapa[r][c] = mapaOriginal[r][c];
                if (mapa[r][c] == 0 || mapa[r][c] == 2) {
                    pastilhasRestantes++;
                }
            }
        }
    }

    public boolean ehParedePixel(int px, int py) {
        int col = Math.floorDiv(px, TILE);
        int lin = Math.floorDiv(py, TILE);

        if (lin < 0 || lin >= mapa.length) return true;
        if (col < 0 || col >= mapa[0].length) return false; // Permite túneis laterais

        return mapa[lin][col] == 1;
    }

    public int coletarItem(int centroX, int centroY) {
        int col = Math.floorDiv(centroX, TILE);
        int lin = Math.floorDiv(centroY, TILE);

        if (lin >= 0 && lin < mapa.length && col >= 0 && col < mapa[0].length) {
            if (mapa[lin][col] == 0) {
                mapa[lin][col] = 3;
                pastilhasRestantes--;
                return 10;
            } else if (mapa[lin][col] == 2) {
                mapa[lin][col] = 3;
                pastilhasRestantes--;
                return 50;
            }
        }
        return 0;
    }

    public void desenhar(Graphics2D g2d, int offsetY) {
        for (int r = 0; r < mapa.length; r++) {
            for (int c = 0; c < mapa[0].length; c++) {
                int px = c * TILE;
                int py = r * TILE + offsetY;
                int celula = mapa[r][c];

                if (celula == 1) {
                    g2d.setColor(new Color(0, 35, 220));
                    g2d.fillRect(px, py, TILE, TILE);
                } else if (celula == 0) {
                    g2d.setColor(Color.WHITE);
                    g2d.fillRect(px + TILE / 2 - 2, py + TILE / 2 - 2, 4, 4);
                } else if (celula == 2) {
                    g2d.setColor(Color.WHITE);
                    g2d.fillRect(px + TILE / 2 - 5, py + TILE / 2 - 5, 10, 10);
                } else if (celula == 4) {
                    g2d.setColor(Color.WHITE);
                    g2d.fillRect(px, py + TILE / 2 - 2, TILE, 4);
                }
            }
        }
    }

    public int getPastilhasRestantes() { return pastilhasRestantes; }
    public int getLarguraPixels() { return mapa[0].length * TILE; }
    public int getAlturaPixels() { return mapa.length * TILE; }
}