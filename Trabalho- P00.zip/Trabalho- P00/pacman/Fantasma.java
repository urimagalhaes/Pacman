package pacman;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Fantasma extends Entidade {
    private final Color corOriginal;
    private final int spawnX;
    private final int spawnY;
    private final Random random = new Random();
    private boolean assustado = false;

    public Fantasma(int x, int y, int tamanho, Color cor) {
        super(x, y, tamanho, 2, cor);
        this.corOriginal = cor;
        this.spawnX = x;
        this.spawnY = y;
        this.dy = -1;
    }

    @Override
    public void atualizar(Labirinto labirinto) {
        int velAtual = assustado ? 1 : velocidade;
        int[][] direcoes = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        List<int[]> validas = new ArrayList<>();

        for (int[] dir : direcoes) {
            // Evita voltar imediatamente para trás, a menos que seja beco sem saída
            if (dir[0] == -dx && dir[1] == -dy) continue;
            if (podeMover(x + dir[0] * velAtual, y + dir[1] * velAtual, labirinto)) {
                validas.add(dir);
            }
        }

        if (validas.isEmpty()) {
            // Beco sem saída: permite inverter direção
            if (podeMover(x - dx * velAtual, y - dy * velAtual, labirinto)) {
                dx = -dx;
                dy = -dy;
            }
        } else {
            // Escolhe nova direção se bater ou em cruzamentos
            boolean bateu = !podeMover(x + dx * velAtual, y + dy * velAtual, labirinto);
            if (bateu || (validas.size() > 1 && random.nextInt(15) == 0)) {
                int[] escolhida = validas.get(random.nextInt(validas.size()));
                dx = escolhida[0];
                dy = escolhida[1];
            }
        }

        int proxX = x + dx * velAtual;
        int proxY = y + dy * velAtual;
        if (podeMover(proxX, proxY, labirinto)) {
            x = aplicarTunel(proxX, labirinto.getLarguraPixels());
            y = proxY;
        }
    }

    @Override
    public void desenhar(Graphics2D g2d) {
        g2d.setColor(assustado ? Color.CYAN : corOriginal);
        g2d.fillOval(x, y, tamanho, tamanho);

        // Olhos simples estilo arcade
        g2d.setColor(Color.WHITE);
        g2d.fillOval(x + 4, y + 5, 5, 5);
        g2d.fillOval(x + tamanho - 9, y + 5, 5, 5);
    }

    public void setAssustado(boolean assustado) {
        this.assustado = assustado;
    }

    public boolean isAssustado() {
        return assustado;
    }

    public void voltarParaBase() {
        setPosicao(spawnX, spawnY);
        this.dy = -1;
        this.assustado = false;
    }
}