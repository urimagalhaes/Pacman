package pacman;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public abstract class Entidade {
    protected int x;
    protected int y;
    protected int dx;
    protected int dy;
    protected int velocidade;
    protected int tamanho;
    protected Color cor;

    public Entidade(int x, int y, int tamanho, int velocidade, Color cor) {
        this.x = x;
        this.y = y;
        this.tamanho = tamanho;
        this.velocidade = velocidade;
        this.cor = cor;
    }

    public abstract void atualizar(Labirinto labirinto);
    public abstract void desenhar(Graphics2D g2d);

    public Rectangle getBounds() {
        return new Rectangle(x + 2, y + 2, tamanho - 4, tamanho - 4);
    }

    protected boolean podeMover(int proxX, int proxY, Labirinto labirinto) {
        int margem = 2;
        int esquerda = proxX + margem;
        int direita = proxX + tamanho - 1 - margem;
        int topo = proxY + margem;
        int base = proxY + tamanho - 1 - margem;

        return !labirinto.ehParedePixel(esquerda, topo) &&
               !labirinto.ehParedePixel(direita, topo) &&
               !labirinto.ehParedePixel(esquerda, base) &&
               !labirinto.ehParedePixel(direita, base);
    }

    protected int aplicarTunel(int posX, int larguraMapa) {
        if (posX < -tamanho / 2) {
            return larguraMapa - tamanho / 2;
        } else if (posX > larguraMapa - tamanho / 2) {
            return -tamanho / 2;
        }
        return posX;
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public void setPosicao(int x, int y) {
        this.x = x;
        this.y = y;
        this.dx = 0;
        this.dy = 0;
    }
}