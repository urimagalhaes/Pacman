package pacman;

import java.awt.Color;
import java.awt.Graphics2D;

public class Jogador extends Entidade {
    private int nextDx;
    private int nextDy;
    private int vidas;
    private int anguloBoca = 30;
    private boolean abrindoBoca = false;

    public Jogador(int x, int y, int tamanho) {
        super(x, y, tamanho, 3, Color.YELLOW);
        this.vidas = 3;
    }

    public void setProximaDirecao(int ndx, int ndy) {
        this.nextDx = ndx;
        this.nextDy = ndy;
    }

    @Override
    public void atualizar(Labirinto labirinto) {
        // Tenta virar na direção solicitada pelo jogador
        if (nextDx != 0 || nextDy != 0) {
            int testeX = x + nextDx * velocidade;
            int testeY = y + nextDy * velocidade;
            if (podeMover(testeX, testeY, labirinto)) {
                dx = nextDx;
                dy = nextDy;
            }
        }

        // Move na direção atual se não houver parede
        int proxX = x + dx * velocidade;
        int proxY = y + dy * velocidade;

        if (podeMover(proxX, proxY, labirinto)) {
            x = aplicarTunel(proxX, labirinto.getLarguraPixels());
            y = proxY;
            animarBoca();
        }
    }

    private void animarBoca() {
        if (abrindoBoca) {
            anguloBoca += 4;
            if (anguloBoca >= 40) abrindoBoca = false;
        } else {
            anguloBoca -= 4;
            if (anguloBoca <= 5) abrindoBoca = true;
        }
    }

    @Override
    public void desenhar(Graphics2D g2d) {
        g2d.setColor(cor);
        int direcaoBase = 0;
        if (dx == 1) direcaoBase = 0;
        else if (dx == -1) direcaoBase = 180;
        else if (dy == -1) direcaoBase = 90;
        else if (dy == 1) direcaoBase = 270;

        g2d.fillArc(x, y, tamanho, tamanho, direcaoBase + anguloBoca, 360 - (2 * anguloBoca));
    }

    public int getVidas() { return vidas; }
    public void perderVida() { vidas--; }
    public void resetarVidas() { vidas = 3; }

    @Override
    public void setPosicao(int x, int y) {
        super.setPosicao(x, y);
        this.nextDx = 0;
        this.nextDy = 0;
    }
}